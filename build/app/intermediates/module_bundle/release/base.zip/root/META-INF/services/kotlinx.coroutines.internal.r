b6.a
